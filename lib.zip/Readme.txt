It's strongly suggested you grab the latest library files from:
https://github.com/adafruit/Adafruit_CircuitPython_Bundle